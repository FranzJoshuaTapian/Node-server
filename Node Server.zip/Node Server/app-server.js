const express = require('express')
var cors = require('cors')
const bcrypt = require('bcrypt')
var jwt = require('jsonwebtoken');
var pg = require('pg')
const { Pool, Client } = pg
/******************************************************/
//Input pgadmin cofiguration details
/******************************************************/
const pool = new Pool({
    user: 'postgres', //postgres username
    host: 'localhost', // localhost or ipaddress
    database: 'university', //database name
    password: '1234', // password
    port: 5432,
})

const app = express()
const port = 3001
app.use(express.json())
var corsOptions = {
    origin: '*',
    optionsSuccessStatus: 200
}
app.use(cors(corsOptions))
const sceret = 'a086fee8e880848750ce9c961b85a6493e9056a96b44eaba9d0a9fe5a5be27058105f0a934ecc42f70e8886fcf1d69783a55f01e705885338f3bc21a0b57becd';

app.post('/login', async (req, res) => {
    console.log(req.body);
    let userid = req.body.userid;
    let pwd = req.body.password;
    let dbPwd = await getPassword(userid);
    try {
        if (await bcrypt.compare(pwd, dbPwd)) {
            res.send(generateJWT({ authToken: userid }));
        } else {
            res.status(500).send('Invalid Details');
        }
    } catch {
        res.status(500).send();
    }

})

async function getPassword(userid) {
    let sql = 'SELECT * FROM public.user WHERE userid=$1';
    let params = [userid];
    try {
        let response = await pool.query(sql, params);
        return response.rows[0].pwd;
    }
    catch {
        return 0;
    }
}


function generateJWT(userdata) {
    var token = jwt.sign(userdata, sceret);
    return token;
}

// function generatePassword(){
//     const passwordNew =  bcrypt.hash('userpassword', 10);
// }

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
})

