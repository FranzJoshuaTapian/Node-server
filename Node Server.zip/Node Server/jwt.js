var jwt = require('jsonwebtoken');
const sceret = 'a086fee8e880848750ce9c961b85a6493e9056a96b44eaba9d0a9fe5a5be27058105f0a934ecc42f70e8886fcf1d69783a55f01e705885338f3bc21a0b57becd';
let data = {user:'Test', role:'Admin'};
var token = jwt.sign(data, sceret);
console.log(token);